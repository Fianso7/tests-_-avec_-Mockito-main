package ma.projet.android.calculapplication;
public interface CalculatorService {
    public double add(double input1, double input2);
    public double sous(double input1, double input2);
    public double multi(double input1, double input2);
    public double div(double input1, double input2);
}